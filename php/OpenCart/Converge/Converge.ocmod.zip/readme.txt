Converge - Elavon - OpenCart Payment Gateway - Release: 1.0

Created 07/3/2015 (Tested with OpenCart Release 2.0.2.0)
Developed by Kevin, supported by PhreeSoft (www.PhreeSoft.com) & Kevin

Selling Points:

1) Able to take CC or debit Card.
2) Simple interface to allow easier theme integration.

Requirements:

	OpenCart 2.0.0.0 or greater

NOTE:

	Translation for English is included.

	For questions, comments, and suggestions, please send email requests to support@phreesoft.com.

SETUP – OpenCart Side Extension Installer
	Login to the admin side
	Go to Extension Installer and upload the zip file
	Give permission to desired Users Converge
	Go to Extentions->Payments and install Converge
	Input your settings information.

SETUP – OpenCart Side Manual
	Upload all files to your opencart directory
	Login to the admin side and give permission to Converge
	Go to Extentions->Payments and install Converge
	Input your settings information.

USAGE – OpenCart Side
	This works similar to most payment moduals by recording transaction results to customer history.

	This will take a creadit card or debit card and change the total amount.
	The transaction code will be recorded into the order history.
